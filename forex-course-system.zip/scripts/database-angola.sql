-- Criar banco de dados para o sistema Marcio Trader Angola
CREATE DATABASE IF NOT EXISTS marcio_trader_angola;
USE marcio_trader_angola;

-- Tabela de matrículas
CREATE TABLE matriculas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    provincia VARCHAR(50) NOT NULL,
    forma_pagamento VARCHAR(100) NOT NULL,
    observacoes TEXT,
    status ENUM('pendente_pagamento', 'pagamento_enviado', 'aprovado', 'rejeitado') DEFAULT 'pendente_pagamento',
    data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_pagamento TIMESTAMP NULL,
    data_aprovacao TIMESTAMP NULL,
    comprovante_email TEXT,
    telegram_enviado BOOLEAN DEFAULT FALSE,
    valor_pago DECIMAL(10,2) DEFAULT 150000.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_status (status),
    INDEX idx_data_envio (data_envio)
);

-- Tabela de configurações do sistema
CREATE TABLE configuracoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    chave VARCHAR(100) NOT NULL UNIQUE,
    valor TEXT NOT NULL,
    descricao TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de logs de emails
CREATE TABLE email_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    matricula_id INT,
    tipo_email ENUM('instrucoes_pagamento', 'aprovacao', 'rejeicao', 'lembrete') NOT NULL,
    destinatario VARCHAR(255) NOT NULL,
    assunto VARCHAR(255) NOT NULL,
    conteudo TEXT,
    status ENUM('enviado', 'erro') NOT NULL,
    erro_mensagem TEXT,
    data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (matricula_id) REFERENCES matriculas(id) ON DELETE CASCADE
);

-- Tabela de estatísticas
CREATE TABLE estatisticas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    data_referencia DATE NOT NULL,
    total_matriculas INT DEFAULT 0,
    matriculas_aprovadas INT DEFAULT 0,
    matriculas_pendentes INT DEFAULT 0,
    receita_total DECIMAL(15,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_data (data_referencia)
);

-- Inserir configurações padrão para Angola
INSERT INTO configuracoes (chave, valor, descricao) VALUES
('telegram_link', 'https://t.me/+MarcioTraderVIP_Angola', 'Link do grupo VIP do Telegram'),
('email_admin', 'marcio@trader.ao', 'Email do administrador'),
('curso_preco', '150000', 'Preço atual do curso em Kwanzas'),
('whatsapp_suporte', '+244999999999', 'WhatsApp para suporte'),
('banco_bai', '0040.0000.40.100.123456.72', 'Conta BAI para pagamentos'),
('banco_bfa', '0006.0000.00.100.123456.15', 'Conta BFA para pagamentos'),
('banco_millennium', '0008.0000.00.100.123456.89', 'Conta Millennium para pagamentos'),
('multicaixa', '999123456', 'Número Multicaixa Express'),
('unitel_money', '+244999123456', 'Número Unitel Money'),
('smtp_host', 'smtp.gmail.com', 'Servidor SMTP'),
('smtp_port', '587', 'Porta SMTP'),
('smtp_user', 'marcio@trader.ao', 'Usuário SMTP'),
('garantia_dias', '30', 'Dias de garantia do curso');

-- Inserir dados de exemplo para demonstração
INSERT INTO matriculas (nome, email, telefone, provincia, forma_pagamento, observacoes, status) VALUES
('Ana Cristina Silva', 'ana.cristina@email.ao', '+244923456789', 'Luanda', 'Transferência Bancária - BAI', 'Muito interessada no curso', 'aprovado'),
('João Miguel Santos', 'joao.miguel@email.ao', '+244934567890', 'Benguela', 'Multicaixa Express', 'Primeira vez em opções binárias', 'pendente_pagamento'),
('Maria Fernanda Costa', 'maria.fernanda@email.ao', '+244945678901', 'Huambo', 'Transferência Bancária - BFA', '', 'pagamento_enviado'),
('Pedro António Neto', 'pedro.antonio@email.ao', '+244956789012', 'Lubango', 'Unitel Money', 'Quero começar o quanto antes', 'aprovado'),
('Carla Beatriz Lopes', 'carla.beatriz@email.ao', '+244967890123', 'Cabinda', 'Transferência Bancária - Millennium', 'Indicação de um amigo', 'pendente_pagamento');

-- Criar views úteis para relatórios
CREATE VIEW view_estatisticas_diarias AS
SELECT 
    DATE(data_envio) as data,
    COUNT(*) as total_matriculas,
    SUM(CASE WHEN status = 'aprovado' THEN 1 ELSE 0 END) as aprovadas,
    SUM(CASE WHEN status = 'pendente_pagamento' THEN 1 ELSE 0 END) as pendentes,
    SUM(CASE WHEN status = 'aprovado' THEN valor_pago ELSE 0 END) as receita
FROM matriculas 
GROUP BY DATE(data_envio)
ORDER BY data DESC;

CREATE VIEW view_matriculas_por_provincia AS
SELECT 
    provincia,
    COUNT(*) as total,
    SUM(CASE WHEN status = 'aprovado' THEN 1 ELSE 0 END) as aprovadas,
    ROUND((SUM(CASE WHEN status = 'aprovado' THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2) as taxa_aprovacao
FROM matriculas 
GROUP BY provincia
ORDER BY total DESC;

-- Procedure para atualizar estatísticas diárias
DELIMITER //
CREATE PROCEDURE AtualizarEstatisticasDiarias()
BEGIN
    INSERT INTO estatisticas (data_referencia, total_matriculas, matriculas_aprovadas, matriculas_pendentes, receita_total)
    SELECT 
        CURDATE(),
        COUNT(*),
        SUM(CASE WHEN status = 'aprovado' THEN 1 ELSE 0 END),
        SUM(CASE WHEN status IN ('pendente_pagamento', 'pagamento_enviado') THEN 1 ELSE 0 END),
        SUM(CASE WHEN status = 'aprovado' THEN valor_pago ELSE 0 END)
    FROM matriculas 
    WHERE DATE(data_envio) = CURDATE()
    ON DUPLICATE KEY UPDATE
        total_matriculas = VALUES(total_matriculas),
        matriculas_aprovadas = VALUES(matriculas_aprovadas),
        matriculas_pendentes = VALUES(matriculas_pendentes),
        receita_total = VALUES(receita_total);
END //
DELIMITER ;

-- Trigger para log automático de mudanças de status
DELIMITER //
CREATE TRIGGER log_status_change 
AFTER UPDATE ON matriculas
FOR EACH ROW
BEGIN
    IF OLD.status != NEW.status THEN
        INSERT INTO email_logs (matricula_id, tipo_email, destinatario, assunto, conteudo, status)
        VALUES (NEW.id, 'aprovacao', NEW.email, 
                CONCAT('Status alterado para: ', NEW.status),
                CONCAT('Matrícula de ', NEW.nome, ' alterada de ', OLD.status, ' para ', NEW.status),
                'enviado');
    END IF;
END //
DELIMITER ;

-- Índices adicionais para performance
CREATE INDEX idx_matriculas_provincia ON matriculas(provincia);
CREATE INDEX idx_matriculas_forma_pagamento ON matriculas(forma_pagamento);
CREATE INDEX idx_email_logs_tipo ON email_logs(tipo_email);
CREATE INDEX idx_email_logs_data ON email_logs(data_envio);

-- Comentários nas tabelas
ALTER TABLE matriculas COMMENT = 'Tabela principal de matrículas do curso Marcio Trader';
ALTER TABLE configuracoes COMMENT = 'Configurações do sistema (dados bancários, links, etc)';
ALTER TABLE email_logs COMMENT = 'Log de todos os emails enviados pelo sistema';
ALTER TABLE estatisticas COMMENT = 'Estatísticas diárias consolidadas';

SELECT 'Banco de dados Marcio Trader Angola criado com sucesso!' as status;
