-- Criar banco de dados para o sistema de curso Forex
CREATE DATABASE IF NOT EXISTS forex_course;
USE forex_course;

-- Tabela de usuários/matrículas
CREATE TABLE matriculas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    telefone VARCHAR(20) NOT NULL,
    observacoes TEXT,
    comprovante_path VARCHAR(500),
    status ENUM('pendente', 'aprovado', 'rejeitado') DEFAULT 'pendente',
    data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_aprovacao TIMESTAMP NULL,
    telegram_enviado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de configurações do sistema
CREATE TABLE configuracoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    chave VARCHAR(100) NOT NULL UNIQUE,
    valor TEXT NOT NULL,
    descricao TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de logs de emails enviados
CREATE TABLE email_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    matricula_id INT,
    tipo_email ENUM('aprovacao', 'rejeicao', 'lembrete') NOT NULL,
    destinatario VARCHAR(255) NOT NULL,
    assunto VARCHAR(255) NOT NULL,
    conteudo TEXT,
    status ENUM('enviado', 'erro') NOT NULL,
    erro_mensagem TEXT,
    data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (matricula_id) REFERENCES matriculas(id) ON DELETE CASCADE
);

-- Inserir configurações padrão
INSERT INTO configuracoes (chave, valor, descricao) VALUES
('telegram_link', 'https://t.me/+exemplo_link_privado', 'Link do grupo privado do Telegram'),
('email_admin', 'admin@forexpro.com', 'Email do administrador'),
('curso_preco', '497', 'Preço atual do curso'),
('smtp_host', 'smtp.gmail.com', 'Servidor SMTP para envio de emails'),
('smtp_port', '587', 'Porta do servidor SMTP'),
('smtp_user', 'contato@forexpro.com', 'Usuário SMTP'),
('smtp_password', '', 'Senha SMTP (configurar via painel admin)');

-- Criar índices para melhor performance
CREATE INDEX idx_matriculas_status ON matriculas(status);
CREATE INDEX idx_matriculas_email ON matriculas(email);
CREATE INDEX idx_matriculas_data_envio ON matriculas(data_envio);
CREATE INDEX idx_email_logs_matricula ON email_logs(matricula_id);
CREATE INDEX idx_email_logs_data ON email_logs(data_envio);
