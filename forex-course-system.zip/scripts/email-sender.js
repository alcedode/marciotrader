// Simulação do sistema de envio de emails (equivalente ao PHPMailer)
// Em produção, você usaria um serviço como Resend, SendGrid, ou Nodemailer

class EmailSender {
  constructor(config) {
    this.config = {
      host: config.host || "smtp.gmail.com",
      port: config.port || 587,
      secure: false,
      auth: {
        user: config.user,
        pass: config.password,
      },
    }
  }

  async sendApprovalEmail(to, name, telegramLink) {
    const emailTemplate = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Matrícula Aprovada - ForexPro</title>
        <style>
          body { font-family: Arial, sans-serif; background-color: #000; color: #fff; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { text-align: center; margin-bottom: 30px; }
          .logo { color: #00ff88; font-size: 24px; font-weight: bold; }
          .content { background-color: #1a1a1a; padding: 30px; border-radius: 10px; }
          .button { 
            display: inline-block; 
            background-color: #00ff88; 
            color: #000; 
            padding: 15px 30px; 
            text-decoration: none; 
            border-radius: 5px; 
            font-weight: bold;
            margin: 20px 0;
          }
          .footer { text-align: center; margin-top: 30px; color: #888; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">ForexPro</div>
          </div>
          <div class="content">
            <h2 style="color: #00ff88;">🎉 Parabéns, ${name}!</h2>
            <p>Sua matrícula foi <strong>aprovada</strong> com sucesso!</p>
            <p>Agora você tem acesso ao nosso grupo VIP exclusivo no Telegram, onde receberá:</p>
            <ul>
              <li>Aulas ao vivo com traders profissionais</li>
              <li>Análises de mercado em tempo real</li>
              <li>Estratégias exclusivas</li>
              <li>Suporte direto da nossa equipe</li>
              <li>Networking com outros traders</li>
            </ul>
            <div style="text-align: center;">
              <a href="${telegramLink}" class="button">🚀 ACESSAR GRUPO VIP</a>
            </div>
            <p><strong>Importante:</strong> Este link é exclusivo e pessoal. Não compartilhe com terceiros.</p>
            <p>Bem-vindo à nossa comunidade de traders de sucesso!</p>
          </div>
          <div class="footer">
            <p>ForexPro - Transformando vidas através do Forex</p>
            <p>contato@forexpro.com | (11) 99999-9999</p>
          </div>
        </div>
      </body>
      </html>
    `

    // Simular envio do email
    console.log(`📧 Enviando email de aprovação para: ${to}`)
    console.log(`📋 Template: Matrícula Aprovada`)
    console.log(`🔗 Link Telegram: ${telegramLink}`)

    // Em produção, aqui você faria a integração real com o serviço de email
    return {
      success: true,
      messageId: `msg_${Date.now()}`,
      message: "Email enviado com sucesso!",
    }
  }

  async sendRejectionEmail(to, name, reason) {
    const emailTemplate = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Informações sobre sua Matrícula - ForexPro</title>
        <style>
          body { font-family: Arial, sans-serif; background-color: #000; color: #fff; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { text-align: center; margin-bottom: 30px; }
          .logo { color: #00ff88; font-size: 24px; font-weight: bold; }
          .content { background-color: #1a1a1a; padding: 30px; border-radius: 10px; }
          .footer { text-align: center; margin-top: 30px; color: #888; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">ForexPro</div>
          </div>
          <div class="content">
            <h2>Olá, ${name}</h2>
            <p>Agradecemos seu interesse em nosso curso de Forex.</p>
            <p>Infelizmente, não foi possível aprovar sua matrícula no momento devido a:</p>
            <p><strong>${reason || "Comprovante de pagamento não identificado"}</strong></p>
            <p>Para resolver esta situação, você pode:</p>
            <ul>
              <li>Enviar um novo comprovante de pagamento</li>
              <li>Entrar em contato conosco pelo WhatsApp</li>
              <li>Responder este email com suas dúvidas</li>
            </ul>
            <p>Nossa equipe está pronta para ajudá-lo!</p>
          </div>
          <div class="footer">
            <p>ForexPro - Suporte ao Cliente</p>
            <p>contato@forexpro.com | (11) 99999-9999</p>
          </div>
        </div>
      </body>
      </html>
    `

    // Simular envio do email
    console.log(`📧 Enviando email de rejeição para: ${to}`)
    console.log(`📋 Motivo: ${reason}`)

    return {
      success: true,
      messageId: `msg_${Date.now()}`,
      message: "Email de rejeição enviado com sucesso!",
    }
  }

  async sendNotificationToAdmin(matriculaData) {
    const emailTemplate = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Nova Matrícula Recebida - ForexPro Admin</title>
        <style>
          body { font-family: Arial, sans-serif; background-color: #000; color: #fff; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { text-align: center; margin-bottom: 30px; }
          .logo { color: #00ff88; font-size: 24px; font-weight: bold; }
          .content { background-color: #1a1a1a; padding: 30px; border-radius: 10px; }
          .data-row { margin: 10px 0; padding: 10px; background-color: #2a2a2a; border-radius: 5px; }
          .button { 
            display: inline-block; 
            background-color: #00ff88; 
            color: #000; 
            padding: 15px 30px; 
            text-decoration: none; 
            border-radius: 5px; 
            font-weight: bold;
            margin: 20px 0;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">ForexPro Admin</div>
          </div>
          <div class="content">
            <h2 style="color: #00ff88;">🔔 Nova Matrícula Recebida</h2>
            <div class="data-row">
              <strong>Nome:</strong> ${matriculaData.nome}
            </div>
            <div class="data-row">
              <strong>Email:</strong> ${matriculaData.email}
            </div>
            <div class="data-row">
              <strong>Telefone:</strong> ${matriculaData.telefone}
            </div>
            <div class="data-row">
              <strong>Data:</strong> ${new Date().toLocaleString("pt-BR")}
            </div>
            <div class="data-row">
              <strong>Comprovante:</strong> ${matriculaData.comprovante}
            </div>
            ${
              matriculaData.observacoes
                ? `
            <div class="data-row">
              <strong>Observações:</strong> ${matriculaData.observacoes}
            </div>
            `
                : ""
            }
            <div style="text-align: center;">
              <a href="/admin" class="button">🔍 REVISAR NO PAINEL</a>
            </div>
          </div>
        </div>
      </body>
      </html>
    `

    console.log(`📧 Notificando admin sobre nova matrícula de: ${matriculaData.nome}`)

    return {
      success: true,
      messageId: `admin_${Date.now()}`,
      message: "Notificação enviada ao admin!",
    }
  }
}

// Configuração do email sender
const emailConfig = {
  host: process.env.SMTP_HOST || "smtp.gmail.com",
  port: process.env.SMTP_PORT || 587,
  user: process.env.SMTP_USER || "contato@forexpro.com",
  password: process.env.SMTP_PASSWORD || "",
}

const emailSender = new EmailSender(emailConfig)

// Exportar para uso nas APIs
if (typeof module !== "undefined" && module.exports) {
  module.exports = { EmailSender, emailSender }
}

console.log("📧 Sistema de email configurado e pronto para uso!")
