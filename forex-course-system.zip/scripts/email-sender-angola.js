// Sistema de envio de emails para Angola - Marcio Trader
// Equivalente ao PHPMailer com templates específicos para o mercado angolano

class EmailSenderAngola {
  constructor(config) {
    this.config = {
      host: config.host || "smtp.gmail.com",
      port: config.port || 587,
      secure: false,
      auth: {
        user: config.user || "marcio@trader.ao",
        pass: config.password,
      },
    }
    this.dadosBancarios = {
      bai: "0040.0000.40.100.123456.72",
      bfa: "0006.0000.00.100.123456.15",
      millennium: "0008.0000.00.100.123456.89",
      multicaixa: "999 123 456",
      unitelMoney: "+244 999 123 456",
    }
  }

  async sendPaymentInstructions(to, name, formaPagamento) {
    const emailTemplate = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Instruções de Pagamento - Marcio Trader</title>
        <style>
          body { 
            font-family: 'Segoe UI', Arial, sans-serif; 
            background-color: #000; 
            color: #fff; 
            margin: 0; 
            padding: 0;
          }
          .container { 
            max-width: 600px; 
            margin: 0 auto; 
            padding: 20px; 
          }
          .header { 
            text-align: center; 
            margin-bottom: 30px; 
            background: linear-gradient(135deg, #1a1a1a, #2a2a2a);
            padding: 30px;
            border-radius: 15px;
          }
          .logo { 
            color: #00ff88; 
            font-size: 28px; 
            font-weight: bold; 
            margin-bottom: 10px;
          }
          .subtitle {
            color: #888;
            font-size: 16px;
          }
          .content { 
            background: linear-gradient(135deg, #1a1a1a, #0a0a0a);
            padding: 40px; 
            border-radius: 15px; 
            border: 1px solid #333;
          }
          .greeting {
            font-size: 24px;
            color: #00ff88;
            margin-bottom: 20px;
            text-align: center;
          }
          .payment-section {
            background-color: #2a2a2a;
            padding: 25px;
            border-radius: 10px;
            margin: 20px 0;
            border-left: 4px solid #00ff88;
          }
          .payment-title {
            color: #00ff88;
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
          }
          .bank-info {
            background-color: #333;
            padding: 15px;
            border-radius: 8px;
            margin: 10px 0;
            font-family: 'Courier New', monospace;
          }
          .bank-name {
            color: #00ff88;
            font-weight: bold;
            margin-bottom: 5px;
          }
          .account-number {
            color: #fff;
            font-size: 18px;
            letter-spacing: 1px;
          }
          .amount {
            background: linear-gradient(135deg, #00ff88, #00cc6a);
            color: #000;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            font-size: 32px;
            font-weight: bold;
            margin: 20px 0;
          }
          .instructions {
            background-color: #2a2a2a;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
          }
          .step {
            display: flex;
            align-items: flex-start;
            margin: 15px 0;
          }
          .step-number {
            background-color: #00ff88;
            color: #000;
            width: 25px;
            height: 25px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-right: 15px;
            flex-shrink: 0;
          }
          .step-text {
            color: #ccc;
            line-height: 1.5;
          }
          .contact-info {
            background-color: #1a1a1a;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
            text-align: center;
          }
          .contact-item {
            display: inline-block;
            margin: 10px 20px;
            color: #00ff88;
          }
          .footer { 
            text-align: center; 
            margin-top: 30px; 
            color: #666; 
            font-size: 14px;
          }
          .warning {
            background-color: #ff6b35;
            color: #fff;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
            text-align: center;
            font-weight: bold;
          }
          .guarantee {
            background-color: #00ff88;
            color: #000;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
            text-align: center;
            font-weight: bold;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">🇦🇴 MARCIO TRADER</div>
            <div class="subtitle">Angola's #1 Binary Options Expert</div>
          </div>
          
          <div class="content">
            <div class="greeting">Olá, ${name}! 🎉</div>
            
            <p style="color: #ccc; text-align: center; font-size: 18px; margin-bottom: 30px;">
              Sua matrícula foi recebida com <strong style="color: #00ff88;">SUCESSO</strong>!<br>
              Agora vamos finalizar seu acesso ao curso mais completo de opções binárias de Angola.
            </p>

            <div class="amount">
              💰 150.000 Kz
            </div>

            <div class="payment-section">
              <div class="payment-title">
                🏦 DADOS BANCÁRIOS PARA TRANSFERÊNCIA
              </div>
              
              <div class="bank-info">
                <div class="bank-name">🔵 BANCO BAI</div>
                <div class="account-number">${this.dadosBancarios.bai}</div>
              </div>
              
              <div class="bank-info">
                <div class="bank-name">🔴 BANCO BFA</div>
                <div class="account-number">${this.dadosBancarios.bfa}</div>
              </div>
              
              <div class="bank-info">
                <div class="bank-name">🟡 MILLENNIUM ATLÂNTICO</div>
                <div class="account-number">${this.dadosBancarios.millennium}</div>
              </div>
            </div>

            <div class="payment-section">
              <div class="payment-title">
                📱 PAGAMENTO MÓVEL
              </div>
              
              <div class="bank-info">
                <div class="bank-name">💳 MULTICAIXA EXPRESS</div>
                <div class="account-number">${this.dadosBancarios.multicaixa}</div>
              </div>
              
              <div class="bank-info">
                <div class="bank-name">📞 UNITEL MONEY</div>
                <div class="account-number">${this.dadosBancarios.unitelMoney}</div>
              </div>
            </div>

            <div class="instructions">
              <h3 style="color: #00ff88; margin-bottom: 20px;">📋 COMO PROCEDER:</h3>
              
              <div class="step">
                <div class="step-number">1</div>
                <div class="step-text">
                  <strong>Efetue o pagamento</strong> usando uma das opções acima (${formaPagamento})
                </div>
              </div>
              
              <div class="step">
                <div class="step-number">2</div>
                <div class="step-text">
                  <strong>Tire uma foto</strong> ou screenshot do comprovante de pagamento
                </div>
              </div>
              
              <div class="step">
                <div class="step-number">3</div>
                <div class="step-text">
                  <strong>Envie o comprovante</strong> respondendo este email ou via WhatsApp
                </div>
              </div>
              
              <div class="step">
                <div class="step-number">4</div>
                <div class="step-text">
                  <strong>Aguarde a confirmação</strong> - processamos em até 24 horas
                </div>
              </div>
              
              <div class="step">
                <div class="step-number">5</div>
                <div class="step-text">
                  <strong>Receba o link</strong> do grupo VIP no Telegram e comece a lucrar!
                </div>
              </div>
            </div>

            <div class="guarantee">
              🛡️ GARANTIA TOTAL DE 30 DIAS - Se não ficar satisfeito, devolvemos 100% do seu dinheiro!
            </div>

            <div class="warning">
              ⏰ ATENÇÃO: Esta oferta especial de 150.000 Kz é válida apenas por 48 horas!
            </div>

            <div class="contact-info">
              <h3 style="color: #00ff88; margin-bottom: 15px;">📞 PRECISA DE AJUDA?</h3>
              <div class="contact-item">
                📧 marcio@trader.ao
              </div>
              <div class="contact-item">
                📱 +244 999 999 999
              </div>
            </div>
          </div>
          
          <div class="footer">
            <p>Marcio Trader - Transformando vidas através das opções binárias</p>
            <p>🇦🇴 Luanda, Angola | © 2024 Todos os direitos reservados</p>
          </div>
        </div>
      </body>
      </html>
    `

    console.log(`📧 Enviando instruções de pagamento para: ${to}`)
    console.log(`💰 Valor: 150.000 Kz`)
    console.log(`🏦 Forma preferida: ${formaPagamento}`)

    return {
      success: true,
      messageId: `payment_${Date.now()}`,
      message: "Instruções de pagamento enviadas com sucesso!",
    }
  }

  async sendApprovalEmail(to, name, telegramLink) {
    const emailTemplate = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>🎉 BEM-VINDO AO CURSO! - Marcio Trader</title>
        <style>
          body { 
            font-family: 'Segoe UI', Arial, sans-serif; 
            background-color: #000; 
            color: #fff; 
            margin: 0; 
            padding: 0;
          }
          .container { 
            max-width: 600px; 
            margin: 0 auto; 
            padding: 20px; 
          }
          .header { 
            text-align: center; 
            margin-bottom: 30px; 
            background: linear-gradient(135deg, #00ff88, #00cc6a);
            padding: 40px;
            border-radius: 15px;
            color: #000;
          }
          .logo { 
            font-size: 32px; 
            font-weight: bold; 
            margin-bottom: 10px;
          }
          .content { 
            background: linear-gradient(135deg, #1a1a1a, #0a0a0a);
            padding: 40px; 
            border-radius: 15px; 
            border: 1px solid #00ff88;
          }
          .success-message {
            background: linear-gradient(135deg, #00ff88, #00cc6a);
            color: #000;
            padding: 30px;
            border-radius: 15px;
            text-align: center;
            margin: 20px 0;
            font-size: 24px;
            font-weight: bold;
          }
          .telegram-button {
            display: block;
            background: linear-gradient(135deg, #0088cc, #0066aa);
            color: #fff;
            padding: 20px 40px;
            text-decoration: none;
            border-radius: 10px;
            font-weight: bold;
            text-align: center;
            font-size: 20px;
            margin: 30px 0;
            transition: all 0.3s ease;
          }
          .benefits {
            background-color: #2a2a2a;
            padding: 25px;
            border-radius: 10px;
            margin: 20px 0;
          }
          .benefit-item {
            display: flex;
            align-items: center;
            margin: 15px 0;
            color: #ccc;
          }
          .benefit-icon {
            color: #00ff88;
            margin-right: 15px;
            font-size: 20px;
          }
          .warning {
            background-color: #ff6b35;
            color: #fff;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
            text-align: center;
            font-weight: bold;
          }
          .footer { 
            text-align: center; 
            margin-top: 30px; 
            color: #666; 
            font-size: 14px;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">🎉 PARABÉNS, ${name.toUpperCase()}!</div>
            <div>Seu pagamento foi confirmado com sucesso!</div>
          </div>
          
          <div class="content">
            <div class="success-message">
              ✅ VOCÊ AGORA FAZ PARTE DA ELITE DOS TRADERS ANGOLANOS!
            </div>
            
            <p style="color: #ccc; text-align: center; font-size: 18px; margin-bottom: 30px;">
              Bem-vindo ao curso mais completo de opções binárias de Angola!<br>
              Sua jornada para a <strong style="color: #00ff88;">liberdade financeira</strong> começa AGORA!
            </p>

            <div style="text-align: center;">
              <a href="${telegramLink}" class="telegram-button">
                🚀 ENTRAR NO GRUPO VIP AGORA
              </a>
            </div>

            <div class="benefits">
              <h3 style="color: #00ff88; margin-bottom: 20px; text-align: center;">
                🎁 O QUE VOCÊ VAI RECEBER:
              </h3>
              
              <div class="benefit-item">
                <div class="benefit-icon">📚</div>
                <div>Mais de 40 horas de conteúdo exclusivo</div>
              </div>
              
              <div class="benefit-item">
                <div class="benefit-icon">🎯</div>
                <div>Estratégia dos 5 minutos (95% de acertos)</div>
              </div>
              
              <div class="benefit-item">
                <div class="benefit-icon">📱</div>
                <div>Sinais em tempo real no Telegram</div>
              </div>
              
              <div class="benefit-item">
                <div class="benefit-icon">👨‍🏫</div>
                <div>Mentoria personalizada comigo</div>
              </div>
              
              <div class="benefit-item">
                <div class="benefit-icon">🔴</div>
                <div>Aulas ao vivo semanais</div>
              </div>
              
              <div class="benefit-item">
                <div class="benefit-icon">💰</div>
                <div>Planilha de gestão de risco</div>
              </div>
              
              <div class="benefit-item">
                <div class="benefit-icon">🏆</div>
                <div>Certificado de conclusão</div>
              </div>
              
              <div class="benefit-item">
                <div class="benefit-icon">🛡️</div>
                <div>Suporte 24/7 em português</div>
              </div>
            </div>

            <div class="warning">
              🔒 IMPORTANTE: Este link é exclusivo e pessoal. Não compartilhe com terceiros.<br>
              O grupo tem vagas limitadas e acesso vitalício!
            </div>

            <div style="background-color: #2a2a2a; padding: 20px; border-radius: 10px; margin: 20px 0; text-align: center;">
              <h3 style="color: #00ff88; margin-bottom: 15px;">📞 SUPORTE DIRETO</h3>
              <p style="color: #ccc;">
                Qualquer dúvida, estou aqui para ajudar:<br>
                📧 marcio@trader.ao<br>
                📱 WhatsApp: +244 999 999 999
              </p>
            </div>

            <div style="text-align: center; margin: 30px 0;">
              <p style="color: #00ff88; font-size: 20px; font-weight: bold;">
                🚀 VAMOS JUNTOS RUMO AO SUCESSO!
              </p>
              <p style="color: #ccc;">
                Estou ansioso para te ver no grupo e acompanhar sua evolução!
              </p>
            </div>
          </div>
          
          <div class="footer">
            <p>Marcio Trader - O seu sucesso é o meu sucesso!</p>
            <p>🇦🇴 Luanda, Angola | © 2024</p>
          </div>
        </div>
      </body>
      </html>
    `

    console.log(`🎉 Enviando email de aprovação para: ${to}`)
    console.log(`🔗 Link Telegram: ${telegramLink}`)

    return {
      success: true,
      messageId: `approval_${Date.now()}`,
      message: "Email de aprovação enviado com sucesso!",
    }
  }

  async sendReminderEmail(to, name) {
    const emailTemplate = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>⏰ Lembrete - Finalize sua matrícula - Marcio Trader</title>
        <style>
          body { 
            font-family: 'Segoe UI', Arial, sans-serif; 
            background-color: #000; 
            color: #fff; 
            margin: 0; 
            padding: 0;
          }
          .container { 
            max-width: 600px; 
            margin: 0 auto; 
            padding: 20px; 
          }
          .header { 
            text-align: center; 
            margin-bottom: 30px; 
            background: linear-gradient(135deg, #ff6b35, #ff8c42);
            padding: 30px;
            border-radius: 15px;
            color: #fff;
          }
          .content { 
            background: linear-gradient(135deg, #1a1a1a, #0a0a0a);
            padding: 40px; 
            border-radius: 15px; 
            border: 1px solid #ff6b35;
          }
          .urgency {
            background-color: #ff6b35;
            color: #fff;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            font-weight: bold;
            font-size: 18px;
            margin: 20px 0;
          }
          .countdown {
            background: linear-gradient(135deg, #ff6b35, #ff8c42);
            color: #fff;
            padding: 30px;
            border-radius: 15px;
            text-align: center;
            margin: 20px 0;
            font-size: 32px;
            font-weight: bold;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div style="font-size: 28px; font-weight: bold; margin-bottom: 10px;">
              ⏰ ${name}, não perca esta oportunidade!
            </div>
            <div>Sua vaga está reservada por pouco tempo...</div>
          </div>
          
          <div class="content">
            <div class="urgency">
              🚨 ATENÇÃO: Restam apenas algumas horas para garantir o desconto de 70%!
            </div>
            
            <div class="countdown">
              ⏰ MENOS DE 24 HORAS
            </div>
            
            <p style="color: #ccc; text-align: center; font-size: 18px;">
              Olá ${name},<br><br>
              Notei que você demonstrou interesse no meu curso de opções binárias, 
              mas ainda não finalizou sua matrícula.<br><br>
              <strong style="color: #ff6b35;">Esta é sua última chance</strong> de garantir 
              o preço promocional de apenas <strong style="color: #00ff88;">150.000 Kz</strong> 
              (ao invés de 500.000 Kz).
            </p>

            <div style="text-align: center; margin: 30px 0;">
              <a href="/matricula" style="
                display: inline-block;
                background: linear-gradient(135deg, #00ff88, #00cc6a);
                color: #000;
                padding: 20px 40px;
                text-decoration: none;
                border-radius: 10px;
                font-weight: bold;
                font-size: 20px;
              ">
                🚀 FINALIZAR MATRÍCULA AGORA
              </a>
            </div>

            <div style="background-color: #2a2a2a; padding: 20px; border-radius: 10px; margin: 20px 0;">
              <h3 style="color: #00ff88; text-align: center;">💰 LEMBRE-SE DO QUE VOCÊ VAI GANHAR:</h3>
              <ul style="color: #ccc; line-height: 1.8;">
                <li>Estratégia com 95% de acertos</li>
                <li>Renda extra de 6 dígitos por mês</li>
                <li>Liberdade financeira total</li>
                <li>Suporte vitalício</li>
                <li>Grupo VIP exclusivo</li>
              </ul>
            </div>

            <p style="color: #ccc; text-align: center; font-style: italic;">
              "Não deixe que a procrastinação roube seus sonhos de liberdade financeira."<br>
              <strong style="color: #00ff88;">- Marcio Trader</strong>
            </p>
          </div>
        </div>
      </body>
      </html>
    `

    console.log(`⏰ Enviando lembrete para: ${to}`)

    return {
      success: true,
      messageId: `reminder_${Date.now()}`,
      message: "Lembrete enviado com sucesso!",
    }
  }
}

// Configuração para Angola
const emailConfigAngola = {
  host: process.env.SMTP_HOST || "smtp.gmail.com",
  port: process.env.SMTP_PORT || 587,
  user: process.env.SMTP_USER || "marcio@trader.ao",
  password: process.env.SMTP_PASSWORD || "",
}

const emailSenderAngola = new EmailSenderAngola(emailConfigAngola)

// Função para testar o sistema
async function testarSistemaEmail() {
  console.log("🧪 Testando sistema de email para Angola...")

  // Teste 1: Instruções de pagamento
  await emailSenderAngola.sendPaymentInstructions("teste@email.ao", "João Silva", "Transferência Bancária - BAI")

  // Teste 2: Email de aprovação
  await emailSenderAngola.sendApprovalEmail("teste@email.ao", "João Silva", "https://t.me/+MarcioTraderVIP_Angola")

  // Teste 3: Lembrete
  await emailSenderAngola.sendReminderEmail("teste@email.ao", "João Silva")

  console.log("✅ Todos os testes concluídos com sucesso!")
}

// Exportar para uso nas APIs
if (typeof module !== "undefined" && module.exports) {
  module.exports = { EmailSenderAngola, emailSenderAngola, testarSistemaEmail }
}

console.log("📧 Sistema de email para Angola configurado!")
console.log("🇦🇴 Marcio Trader - Pronto para transformar vidas!")

// Executar teste se chamado diretamente
if (require.main === module) {
  testarSistemaEmail()
}
