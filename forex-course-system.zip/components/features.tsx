import { Card, CardContent } from "@/components/ui/card"
import { BookOpen, Users, Trophy, Zap, Shield, Clock, Target, BarChart3 } from "lucide-react"

const features = [
  {
    icon: Target,
    title: "Estratégia dos 5 Minutos",
    description: "Método exclusivo para operar com alta precisão em timeframes curtos",
  },
  {
    icon: BarChart3,
    title: "Análise Técnica Avançada",
    description: "Aprenda a ler gráficos como um profissional e identificar oportunidades",
  },
  {
    icon: Users,
    title: "Mentoria Personalizada",
    description: "Acompanhamento direto comigo através do grupo VIP no Telegram",
  },
  {
    icon: Trophy,
    title: "Resultados Comprovados",
    description: "95% de taxa de acerto com estratégias testadas no mercado real",
  },
  {
    icon: Zap,
    title: "Sinais em Tempo Real",
    description: "Receba alertas das melhores oportunidades direto no seu celular",
  },
  {
    icon: Shield,
    title: "Gestão de Risco",
    description: "Aprenda a proteger seu capital e operar com segurança",
  },
  {
    icon: BookOpen,
    title: "Material Exclusivo",
    description: "E-books, planilhas e indicadores desenvolvidos especialmente para Angola",
  },
  {
    icon: Clock,
    title: "Suporte 24/7",
    description: "Tire suas dúvidas a qualquer hora com nossa equipe especializada",
  },
]

export function Features() {
  return (
    <section className="py-24 bg-gradient-to-b from-gray-900 to-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-white to-neon-green bg-clip-text text-transparent">
            O que você vai aprender
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Um curso completo e prático, desenvolvido especialmente para o mercado angolano, com estratégias que
            realmente funcionam.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="bg-gray-900/50 border-gray-800 hover:border-neon-green/30 transition-all duration-300 group hover:scale-105"
            >
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-neon-green/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-neon-green/20 transition-colors">
                  <feature.icon className="w-6 h-6 text-neon-green" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-4">{feature.title}</h3>
                <p className="text-gray-400 leading-relaxed text-sm">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Bonus Section */}
        <div className="mt-16 bg-gradient-to-r from-neon-green/10 to-transparent border border-neon-green/20 rounded-2xl p-8">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-white mb-4">🎁 Bônus Exclusivos</h3>
            <div className="grid md:grid-cols-3 gap-6 mt-8">
              <div className="text-center">
                <div className="text-4xl mb-2">📱</div>
                <h4 className="font-semibold text-white mb-2">App Mobile</h4>
                <p className="text-gray-400 text-sm">Aplicativo exclusivo para receber sinais</p>
              </div>
              <div className="text-center">
                <div className="text-4xl mb-2">💰</div>
                <h4 className="font-semibold text-white mb-2">Capital Inicial</h4>
                <p className="text-gray-400 text-sm">Dicas para começar com pouco dinheiro</p>
              </div>
              <div className="text-center">
                <div className="text-4xl mb-2">🏆</div>
                <h4 className="font-semibold text-white mb-2">Certificado</h4>
                <p className="text-gray-400 text-sm">Certificado de conclusão reconhecido</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
