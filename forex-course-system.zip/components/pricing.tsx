import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, Star, Zap } from "lucide-react"
import Link from "next/link"

export function Pricing() {
  return (
    <section className="py-24 bg-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-white to-neon-green bg-clip-text text-transparent">
            Transforme sua vida hoje
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Investimento que vai mudar sua realidade financeira para sempre
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="bg-gradient-to-br from-gray-900 to-black border-neon-green/30 relative overflow-hidden">
            {/* Popular badge */}
            <div className="absolute top-0 right-0 bg-neon-green text-black px-6 py-3 text-sm font-bold">
              🔥 OFERTA LIMITADA
            </div>

            <CardHeader className="text-center pb-8 pt-16">
              <div className="flex justify-center mb-4">
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-6 h-6 fill-neon-green text-neon-green" />
                  ))}
                </div>
              </div>
              <CardTitle className="text-3xl font-bold text-white mb-6">Curso Completo de Opções Binárias</CardTitle>
              <div className="text-center">
                <div className="text-6xl font-bold text-neon-green mb-2">150.000 Kz</div>
                <div className="text-gray-400 line-through text-2xl mb-2">500.000 Kz</div>
                <div className="text-neon-green font-semibold text-lg">💥 Desconto de 70% por tempo limitado!</div>
              </div>
            </CardHeader>

            <CardContent className="px-8 pb-8">
              <div className="grid md:grid-cols-2 gap-8 mb-8">
                <div>
                  <h4 className="font-semibold text-white mb-6 flex items-center gap-2">
                    <Zap className="w-5 h-5 text-neon-green" />O que está incluído:
                  </h4>
                  <ul className="space-y-4">
                    {[
                      "Acesso vitalício ao curso",
                      "Mais de 40 horas de conteúdo",
                      "Estratégia dos 5 minutos",
                      "Grupo VIP no Telegram",
                      "Sinais em tempo real",
                      "Suporte personalizado",
                      "Material em português",
                      "Aulas ao vivo semanais",
                    ].map((item, index) => (
                      <li key={index} className="flex items-center gap-3">
                        <Check className="w-5 h-5 text-neon-green flex-shrink-0" />
                        <span className="text-gray-300">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-white mb-6 flex items-center gap-2">
                    <Star className="w-5 h-5 text-neon-green" />
                    Bônus exclusivos:
                  </h4>
                  <ul className="space-y-4">
                    {[
                      "App mobile para sinais",
                      "E-book: Psicologia do Trader",
                      "Planilha de gestão de risco",
                      "Indicadores personalizados",
                      "Sessões de trading ao vivo",
                      "Certificado de conclusão",
                      "Garantia de 30 dias",
                      "Consultoria individual",
                    ].map((item, index) => (
                      <li key={index} className="flex items-center gap-3">
                        <Check className="w-5 h-5 text-neon-green flex-shrink-0" />
                        <span className="text-gray-300">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="bg-neon-green/10 border border-neon-green/30 rounded-lg p-6 mb-8">
                <div className="text-center">
                  <h4 className="text-neon-green font-bold text-lg mb-2">🎯 Garantia de Resultados</h4>
                  <p className="text-gray-300">
                    Se você não conseguir pelo menos recuperar o investimento em 60 dias seguindo nosso método,
                    devolvemos 100% do seu dinheiro!
                  </p>
                </div>
              </div>

              <div className="text-center">
                <Link href="/matricula">
                  <Button
                    size="lg"
                    className="bg-neon-green hover:bg-neon-green/90 text-black font-bold px-12 py-6 text-xl w-full md:w-auto mb-4"
                  >
                    🚀 QUERO COMEÇAR AGORA
                  </Button>
                </Link>
                <p className="text-sm text-gray-400">
                  🔒 Pagamento 100% seguro | 💳 Aceitamos todas as formas de pagamento
                </p>
                <p className="text-xs text-gray-500 mt-2">⏰ Restam apenas 48 horas para esta oferta especial</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
