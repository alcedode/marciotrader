"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, Award, Users, TrendingUp, Target } from "lucide-react"

const carouselItems = [
  {
    type: "image",
    src: "/placeholder.svg?height=400&width=600",
    title: "Formando Novos Traders",
    description: "Mais de 2000 alunos já transformaram suas vidas financeiras",
  },
  {
    type: "image",
    src: "/placeholder.svg?height=400&width=600",
    title: "Análise Profissional",
    description: "Estratégias baseadas em análise técnica avançada",
  },
  {
    type: "image",
    src: "/placeholder.svg?height=400&width=600",
    title: "Resultados Reais",
    description: "O sucesso nas opções binárias mudou minha vida",
  },
  {
    type: "video",
    src: "/placeholder.svg?height=400&width=600",
    title: "Estratégia Exclusiva",
    description: "Aprenda o método que uso para ter 95% de acertos",
  },
]

const achievements = [
  {
    icon: Award,
    title: "Trader Certificado",
    description: "Certificação internacional em análise técnica",
  },
  {
    icon: Users,
    title: "2000+ Alunos",
    description: "Maior comunidade de traders de Angola",
  },
  {
    icon: TrendingUp,
    title: "95% de Acertos",
    description: "Taxa de sucesso comprovada nas operações",
  },
  {
    icon: Target,
    title: "5 Anos de Mercado",
    description: "Experiência sólida em opções binárias",
  },
]

export function About() {
  const [currentSlide, setCurrentSlide] = useState(0)

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % carouselItems.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + carouselItems.length) % carouselItems.length)
  }

  return (
    <section className="py-24 bg-gradient-to-b from-black to-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-white to-neon-green bg-clip-text text-transparent">
            Conheça Marcio Trader
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            De funcionário público a trader milionário. Descubra como transformei minha vida e agora ajudo outros
            angolanos a alcançar a liberdade financeira.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Carousel */}
          <div className="relative">
            <div className="relative overflow-hidden rounded-2xl bg-gray-900 border border-gray-800">
              <div className="aspect-video relative">
                <img
                  src={carouselItems[currentSlide].src || "/placeholder.svg"}
                  alt={carouselItems[currentSlide].title}
                  className="w-full h-full object-cover"
                />
                {carouselItems[currentSlide].type === "video" && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                    <div className="w-16 h-16 bg-neon-green rounded-full flex items-center justify-center">
                      <div className="w-0 h-0 border-l-[12px] border-l-black border-y-[8px] border-y-transparent ml-1"></div>
                    </div>
                  </div>
                )}
              </div>

              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-2">{carouselItems[currentSlide].title}</h3>
                <p className="text-gray-400">{carouselItems[currentSlide].description}</p>
              </div>
            </div>

            {/* Carousel Controls */}
            <div className="flex justify-between items-center mt-4">
              <Button
                variant="outline"
                size="sm"
                onClick={prevSlide}
                className="border-gray-600 text-gray-300 hover:bg-gray-800 bg-transparent"
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>

              <div className="flex gap-2">
                {carouselItems.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-3 h-3 rounded-full transition-colors ${
                      index === currentSlide ? "bg-neon-green" : "bg-gray-600"
                    }`}
                  />
                ))}
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={nextSlide}
                className="border-gray-600 text-gray-300 hover:bg-gray-800 bg-transparent"
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Story */}
          <div className="space-y-6">
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
              <h3 className="text-2xl font-bold text-white mb-4">Minha História</h3>
              <div className="space-y-4 text-gray-300">
                <p>
                  Há 5 anos, eu era apenas mais um funcionário público em Luanda, ganhando um salário que mal cobria as
                  despesas básicas da família.
                </p>
                <p>
                  Tudo mudou quando descobri as opções binárias. Comecei estudando sozinho, perdendo dinheiro, mas nunca
                  desisti.
                </p>
                <p>
                  Hoje, sou trader profissional e já ajudei mais de 2000 angolanos a transformar suas vidas financeiras
                  através do meu método exclusivo.
                </p>
                <p className="text-neon-green font-semibold">
                  "Se eu consegui sair da zona de conforto e alcançar a liberdade financeira, você também pode!"
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Achievements */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {achievements.map((achievement, index) => (
            <Card
              key={index}
              className="bg-gray-900/50 border-gray-800 hover:border-neon-green/30 transition-all duration-300 group"
            >
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-neon-green/10 rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:bg-neon-green/20 transition-colors">
                  <achievement.icon className="w-6 h-6 text-neon-green" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{achievement.title}</h3>
                <p className="text-gray-400 text-sm">{achievement.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
