"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight, TrendingUp, DollarSign, BarChart3, Play } from "lucide-react"
import Link from "next/link"
import { useState } from "react"

export function Hero() {
  const [isVideoPlaying, setIsVideoPlaying] = useState(false)

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-black via-gray-900 to-black">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-neon-green/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-neon-green/5 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* Grid pattern overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(0,255,136,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,136,0.03)_1px,transparent_1px)] bg-[size:50px_50px]"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left side - Content */}
          <div className="text-center lg:text-left">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-neon-green/10 border border-neon-green/20 rounded-full px-4 py-2 mb-8">
              <TrendingUp className="w-4 h-4 text-neon-green" />
              <span className="text-neon-green text-sm font-medium">{"#1 Trader de Angola"}</span>
            </div>

            {/* Main heading */}
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-white via-gray-200 to-neon-green bg-clip-text text-transparent leading-tight">
              Domine as
              <br />
              <span className="text-neon-green">Opções Binárias</span>
              <br />
              com Marcio Trader
            </h1>

            {/* Subtitle */}
            <p className="text-xl md:text-2xl text-gray-300 mb-8 leading-relaxed">
              Aprenda as estratégias que me fizeram ganhar
              <br />
              <span className="text-neon-green font-semibold">milhões de kwanzas</span> no mercado financeiro
            </p>

            {/* Stats */}
            <div className="flex flex-wrap justify-center lg:justify-start gap-8 mb-12">
              <div className="text-center">
                <div className="text-3xl font-bold text-neon-green">2000+</div>
                <div className="text-gray-400">Alunos Formados</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-neon-green">95%</div>
                <div className="text-gray-400">Taxa de Sucesso</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-neon-green">5 Anos</div>
                <div className="text-gray-400">de Experiência</div>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start items-center">
              <Link href="/matricula">
                <Button
                  size="lg"
                  className="bg-neon-green hover:bg-neon-green/90 text-black font-semibold px-8 py-4 text-lg group"
                >
                  Começar Agora
                  <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <Button
                variant="outline"
                size="lg"
                className="border-neon-green/30 text-neon-green hover:bg-neon-green/10 px-8 py-4 text-lg bg-transparent"
                onClick={() => setIsVideoPlaying(true)}
              >
                <Play className="mr-2 w-5 h-5" />
                Ver Apresentação
              </Button>
            </div>
          </div>

          {/* Right side - Marcio's Photo/Video */}
          <div className="relative">
            <div className="relative w-full max-w-md mx-auto">
              {/* Main photo container */}
              <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-neon-green/20 to-transparent p-1">
                <div className="bg-gray-900 rounded-xl overflow-hidden">
                  <img
                    src="/placeholder.svg?height=600&width=400"
                    alt="Marcio Trader"
                    className="w-full h-auto object-cover"
                  />
                </div>
              </div>

              {/* Floating elements */}
              <div className="absolute -top-4 -right-4 bg-neon-green text-black px-4 py-2 rounded-lg font-bold text-sm animate-bounce">
                🚀 +500% ROI
              </div>
              <div className="absolute -bottom-4 -left-4 bg-gray-900 border border-neon-green/30 text-neon-green px-4 py-2 rounded-lg font-semibold text-sm">
                💰 Trader Profissional
              </div>
            </div>
          </div>
        </div>

        {/* Trust indicators */}
        <div className="mt-16 flex flex-wrap justify-center items-center gap-8 opacity-60">
          <div className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-neon-green" />
            <span className="text-gray-400">Resultados Reais</span>
          </div>
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-neon-green" />
            <span className="text-gray-400">Estratégias Comprovadas</span>
          </div>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-neon-green" />
            <span className="text-gray-400">Suporte em Português</span>
          </div>
        </div>
      </div>

      {/* Video Modal */}
      {isVideoPlaying && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
          <div className="relative w-full max-w-4xl">
            <button
              onClick={() => setIsVideoPlaying(false)}
              className="absolute -top-12 right-0 text-white hover:text-neon-green text-2xl"
            >
              ✕
            </button>
            <div className="bg-gray-900 rounded-lg overflow-hidden">
              <div className="aspect-video bg-gray-800 flex items-center justify-center">
                <div className="text-center">
                  <Play className="w-16 h-16 text-neon-green mx-auto mb-4" />
                  <p className="text-white">Vídeo de Apresentação do Marcio Trader</p>
                  <p className="text-gray-400 text-sm mt-2">Clique para reproduzir</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  )
}
