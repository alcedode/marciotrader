import { Mail, Phone, MapPin, MessageCircle } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-black border-t border-gray-800">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-2xl font-bold text-neon-green mb-4">Marcio Trader</h3>
            <p className="text-gray-400 mb-4">
              O maior especialista em opções binárias de Angola. Transformando vidas através da educação financeira.
            </p>
            <div className="flex gap-4">
              <div className="w-10 h-10 bg-neon-green/20 rounded-full flex items-center justify-center">
                <span className="text-neon-green font-bold">MT</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">Links Rápidos</h4>
            <ul className="space-y-2 text-gray-400">
              <li>
                <a href="#" className="hover:text-neon-green transition-colors">
                  Sobre o Marcio
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-neon-green transition-colors">
                  Curso
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-neon-green transition-colors">
                  Depoimentos
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-neon-green transition-colors">
                  FAQ
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">Suporte</h4>
            <ul className="space-y-2 text-gray-400">
              <li>
                <a href="#" className="hover:text-neon-green transition-colors">
                  Central de Ajuda
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-neon-green transition-colors">
                  Termos de Uso
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-neon-green transition-colors">
                  Política de Privacidade
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-neon-green transition-colors">
                  Garantia
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">Contato</h4>
            <div className="space-y-3 text-gray-400">
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-neon-green" />
                <span>marcio@trader.ao</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-neon-green" />
                <span>+244 999 999 999</span>
              </div>
              <div className="flex items-center gap-3">
                <MessageCircle className="w-5 h-5 text-neon-green" />
                <span>WhatsApp: +244 999 999 999</span>
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-neon-green" />
                <span>Luanda, Angola</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-center md:text-left">
              &copy; 2024 Marcio Trader. Todos os direitos reservados.
            </p>
            <p className="text-gray-500 text-sm mt-4 md:mt-0">🇦🇴 Feito com ❤️ em Angola</p>
          </div>
        </div>
      </div>
    </footer>
  )
}
