import { Card, CardContent } from "@/components/ui/card"
import { Star, Quote } from "lucide-react"

const testimonials = [
  {
    name: "Ana Cristina",
    role: "Professora - Luanda",
    content:
      "Em 3 meses consegui comprar meu primeiro carro só com os lucros das opções binárias. O método do Marcio realmente funciona!",
    rating: 5,
    profit: "+250.000 Kz",
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    name: "João Miguel",
    role: "Estudante - Benguela",
    content:
      "Comecei com apenas 50.000 Kz e hoje já tenho uma renda mensal de 6 dígitos. Mudou completamente minha vida!",
    rating: 5,
    profit: "+800.000 Kz",
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    name: "Maria Santos",
    role: "Enfermeira - Huambo",
    content: "O suporte do Marcio é incrível! Sempre disponível para tirar dúvidas. Hoje sou uma trader independente.",
    rating: 5,
    profit: "+450.000 Kz",
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    name: "Pedro Neto",
    role: "Comerciante - Lubango",
    content:
      "Nunca pensei que seria possível ganhar tanto dinheiro online. As estratégias são simples e muito eficazes!",
    rating: 5,
    profit: "+600.000 Kz",
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    name: "Carla Fernandes",
    role: "Secretária - Cabinda",
    content: "Em 6 meses consegui quitar todas as minhas dívidas e ainda sobrou para investir mais. Gratidão eterna!",
    rating: 5,
    profit: "+350.000 Kz",
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    name: "António Silva",
    role: "Mecânico - Malanje",
    content: "O curso mudou minha mentalidade financeira. Hoje entendo o mercado e opero com confiança total.",
    rating: 5,
    profit: "+520.000 Kz",
    image: "/placeholder.svg?height=80&width=80",
  },
]

export function Testimonials() {
  return (
    <section className="py-24 bg-gradient-to-b from-gray-900 to-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-white to-neon-green bg-clip-text text-transparent">
            Histórias de sucesso reais
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Veja como outros angolanos transformaram suas vidas com nosso método
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <Card
              key={index}
              className="bg-gray-900/50 border-gray-800 hover:border-neon-green/30 transition-all duration-300 hover:scale-105"
            >
              <CardContent className="p-6">
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-neon-green text-neon-green" />
                  ))}
                </div>

                <Quote className="w-8 h-8 text-neon-green/30 mb-4" />

                <p className="text-gray-300 mb-6 leading-relaxed text-sm">{testimonial.content}</p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={testimonial.image || "/placeholder.svg"}
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-full object-cover border-2 border-neon-green/30"
                    />
                    <div>
                      <div className="font-semibold text-white text-sm">{testimonial.name}</div>
                      <div className="text-xs text-gray-400">{testimonial.role}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-neon-green font-bold text-sm">{testimonial.profit}</div>
                    <div className="text-xs text-gray-400">em 6 meses</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Video testimonials section */}
        <div className="mt-16 text-center">
          <h3 className="text-2xl font-bold text-white mb-8">📹 Depoimentos em Vídeo</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="relative group cursor-pointer">
                <div className="aspect-video bg-gray-800 rounded-lg overflow-hidden border border-gray-700 group-hover:border-neon-green/50 transition-colors">
                  <img
                    src={`/placeholder.svg?height=200&width=300&query=video thumbnail angolan person testimonial ${i}`}
                    alt={`Depoimento ${i}`}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/40 group-hover:bg-black/20 transition-colors">
                    <div className="w-12 h-12 bg-neon-green rounded-full flex items-center justify-center">
                      <div className="w-0 h-0 border-l-[8px] border-l-black border-y-[6px] border-y-transparent ml-1"></div>
                    </div>
                  </div>
                </div>
                <p className="text-gray-400 text-sm mt-2">Depoimento real de aluno</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
