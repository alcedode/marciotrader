"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CheckCircle, AlertCircle, Loader2, Mail, Phone, User, CreditCard } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface FormData {
  nome: string
  email: string
  telefone: string
  provincia: string
  formaPagamento: string
  observacoes: string
}

type SubmissionStatus = "idle" | "sending" | "success" | "error"

export default function MatriculaPage() {
  const [formData, setFormData] = useState<FormData>({
    nome: "",
    email: "",
    telefone: "",
    provincia: "",
    formaPagamento: "",
    observacoes: "",
  })

  const [status, setStatus] = useState<SubmissionStatus>("idle")
  const [errorMessage, setErrorMessage] = useState("")

  const provincias = [
    "Luanda",
    "Benguela",
    "Huambo",
    "Lobito",
    "Cabinda",
    "Huíla",
    "Malanje",
    "Namibe",
    "Moxico",
    "Cuando Cubango",
    "Cunene",
    "Uíge",
    "Zaire",
    "Lunda Norte",
    "Lunda Sul",
    "Bengo",
    "Bié",
    "Cuanza Norte",
    "Cuanza Sul",
  ]

  const formasPagamento = [
    "Transferência Bancária - BAI",
    "Transferência Bancária - BFA",
    "Transferência Bancária - Millennium",
    "Transferência Bancária - Standard Bank",
    "Multicaixa Express",
    "Unitel Money",
    "Dinheiro (Depósito)",
  ]

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setStatus("sending")
    setErrorMessage("")

    try {
      // Simulate API call
      await new Promise((resolve, reject) => {
        setTimeout(() => {
          // Simulate random success/error for demo
          if (Math.random() > 0.1) {
            resolve(true)
          } else {
            reject(new Error("Erro de conexão. Tente novamente."))
          }
        }, 3000)
      })

      setStatus("success")
    } catch (error) {
      setStatus("error")
      setErrorMessage(error instanceof Error ? error.message : "Erro desconhecido")
    }
  }

  // Success Modal
  if (status === "success") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black flex items-center justify-center p-4">
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center">
          <Card className="max-w-lg w-full bg-gray-900 border-neon-green/30 animate-in fade-in-0 zoom-in-95 duration-300">
            <CardContent className="p-8 text-center">
              <div className="w-20 h-20 bg-neon-green/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-12 h-12 text-neon-green" />
              </div>
              <h2 className="text-3xl font-bold text-white mb-4">🎉 Matrícula Enviada!</h2>
              <p className="text-gray-300 mb-6 leading-relaxed">
                Parabéns! Sua solicitação foi enviada com sucesso.
                <br />
                <br />
                <strong className="text-neon-green">Próximos passos:</strong>
                <br />
                1. Você receberá um email com os dados para pagamento
                <br />
                2. Após confirmar o pagamento, envie o comprovante por email
                <br />
                3. Em até 24h você receberá o link do grupo VIP
              </p>
              <div className="bg-neon-green/10 border border-neon-green/30 rounded-lg p-4 mb-6">
                <p className="text-neon-green font-semibold text-sm">
                  📧 Verifique sua caixa de entrada (e spam) nos próximos minutos!
                </p>
              </div>
              <Button
                onClick={() => (window.location.href = "/")}
                className="bg-neon-green hover:bg-neon-green/90 text-black font-semibold px-8 py-3"
              >
                Voltar ao Início
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Error Modal
  if (status === "error") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black flex items-center justify-center p-4">
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center">
          <Card className="max-w-lg w-full bg-gray-900 border-red-500/30 animate-in fade-in-0 zoom-in-95 duration-300">
            <CardContent className="p-8 text-center">
              <div className="w-20 h-20 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <AlertCircle className="w-12 h-12 text-red-500" />
              </div>
              <h2 className="text-3xl font-bold text-white mb-4">❌ Erro no Envio</h2>
              <p className="text-gray-300 mb-6">
                Ops! Ocorreu um erro ao enviar sua matrícula:
                <br />
                <span className="text-red-400 font-semibold">{errorMessage}</span>
              </p>
              <div className="flex gap-4 justify-center">
                <Button
                  onClick={() => setStatus("idle")}
                  className="bg-neon-green hover:bg-neon-green/90 text-black font-semibold"
                >
                  Tentar Novamente
                </Button>
                <Button
                  variant="outline"
                  onClick={() => (window.location.href = "/")}
                  className="border-gray-600 text-gray-300 hover:bg-gray-800 bg-transparent"
                >
                  Voltar ao Início
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Loading Modal
  if (status === "sending") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black flex items-center justify-center p-4">
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center">
          <Card className="max-w-lg w-full bg-gray-900 border-neon-green/30 animate-in fade-in-0 zoom-in-95 duration-300">
            <CardContent className="p-8 text-center">
              <div className="w-20 h-20 bg-neon-green/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Loader2 className="w-12 h-12 text-neon-green animate-spin" />
              </div>
              <h2 className="text-3xl font-bold text-white mb-4">📤 Enviando...</h2>
              <p className="text-gray-300 mb-6">
                Estamos processando sua matrícula.
                <br />
                Por favor, aguarde alguns instantes...
              </p>
              <div className="w-full bg-gray-800 rounded-full h-2 mb-4">
                <div className="bg-neon-green h-2 rounded-full animate-pulse" style={{ width: "70%" }}></div>
              </div>
              <p className="text-sm text-gray-400">Não feche esta página</p>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black p-4">
      <div className="container mx-auto max-w-3xl py-12">
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-white to-neon-green bg-clip-text text-transparent mb-4">
            Garanta sua vaga agora!
          </h1>
          <p className="text-gray-300 text-lg">
            Preencha os dados abaixo e receba as instruções de pagamento por email
          </p>
        </div>

        <Card className="bg-gray-900/50 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <User className="w-6 h-6 text-neon-green" />
              Dados da Matrícula
            </CardTitle>
            <CardDescription className="text-gray-400">
              Após o envio, você receberá um email com os dados para pagamento
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nome" className="text-white">
                    Nome Completo *
                  </Label>
                  <Input
                    id="nome"
                    name="nome"
                    value={formData.nome}
                    onChange={handleInputChange}
                    required
                    className="bg-gray-800 border-gray-700 text-white focus:border-neon-green"
                    placeholder="Seu nome completo"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-white">
                    Email *
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="bg-gray-800 border-gray-700 text-white focus:border-neon-green"
                    placeholder="seu@email.com"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="telefone" className="text-white">
                    Telefone/WhatsApp *
                  </Label>
                  <Input
                    id="telefone"
                    name="telefone"
                    value={formData.telefone}
                    onChange={handleInputChange}
                    required
                    className="bg-gray-800 border-gray-700 text-white focus:border-neon-green"
                    placeholder="+244 999 999 999"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="provincia" className="text-white">
                    Província *
                  </Label>
                  <Select onValueChange={(value) => handleSelectChange("provincia", value)}>
                    <SelectTrigger className="bg-gray-800 border-gray-700 text-white focus:border-neon-green">
                      <SelectValue placeholder="Selecione sua província" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-700">
                      {provincias.map((provincia) => (
                        <SelectItem key={provincia} value={provincia} className="text-white hover:bg-gray-700">
                          {provincia}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="formaPagamento" className="text-white">
                  Forma de Pagamento Preferida *
                </Label>
                <Select onValueChange={(value) => handleSelectChange("formaPagamento", value)}>
                  <SelectTrigger className="bg-gray-800 border-gray-700 text-white focus:border-neon-green">
                    <SelectValue placeholder="Como prefere pagar?" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-700">
                    {formasPagamento.map((forma) => (
                      <SelectItem key={forma} value={forma} className="text-white hover:bg-gray-700">
                        {forma}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="observacoes" className="text-white">
                  Observações
                </Label>
                <Textarea
                  id="observacoes"
                  name="observacoes"
                  value={formData.observacoes}
                  onChange={handleInputChange}
                  className="bg-gray-800 border-gray-700 text-white focus:border-neon-green"
                  placeholder="Alguma dúvida ou observação? (opcional)"
                  rows={3}
                />
              </div>

              <Alert className="bg-neon-green/10 border-neon-green/30">
                <Mail className="h-4 w-4 text-neon-green" />
                <AlertDescription className="text-gray-300">
                  <strong className="text-neon-green">Como funciona:</strong>
                  <br />
                  1. Você receberá um email com os dados bancários para pagamento
                  <br />
                  2. Após pagar, envie o comprovante por email ou WhatsApp
                  <br />
                  3. Em até 24h você receberá o link do grupo VIP no Telegram
                </AlertDescription>
              </Alert>

              <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6">
                <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-neon-green" />
                  Dados Bancários (serão enviados por email)
                </h3>
                <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-400">
                  <div>
                    <p>
                      <strong>BAI:</strong> 0000.0000.0000.0000
                    </p>
                    <p>
                      <strong>BFA:</strong> 0000.0000.0000.0000
                    </p>
                  </div>
                  <div>
                    <p>
                      <strong>Multicaixa:</strong> 999 999 999
                    </p>
                    <p>
                      <strong>Unitel Money:</strong> +244 999 999 999
                    </p>
                  </div>
                </div>
              </div>

              <Button
                type="submit"
                disabled={status === "sending"}
                className="w-full bg-neon-green hover:bg-neon-green/90 text-black font-bold py-4 text-lg"
              >
                {status === "sending" ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Enviando Matrícula...
                  </>
                ) : (
                  <>
                    <Mail className="mr-2 h-5 w-5" />
                    Enviar Matrícula
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="mt-8 text-center">
          <p className="text-gray-400 text-sm mb-4">Dúvidas? Entre em contato:</p>
          <div className="flex flex-wrap justify-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-neon-green" />
              <span className="text-neon-green">marcio@trader.ao</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-neon-green" />
              <span className="text-neon-green">+244 999 999 999</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
