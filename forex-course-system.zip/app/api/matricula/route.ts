import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.json()

    const { nome, email, telefone, provincia, formaPagamento, observacoes } = formData

    // Here you would typically:
    // 1. Save the matricula data to database
    // 2. Send email with payment instructions
    // 3. Send notification to admin

    // Simulate database save
    const matriculaData = {
      nome,
      email,
      telefone,
      provincia,
      formaPagamento,
      observacoes,
      status: "pendente_pagamento",
      dataEnvio: new Date().toISOString(),
    }

    console.log("Nova matrícula recebida:", matriculaData)

    // Simulate sending email with payment instructions
    const emailContent = `
      Olá ${nome}!
      
      Sua matrícula foi recebida com sucesso!
      
      DADOS PARA PAGAMENTO:
      Valor: 150.000 Kz
      
      OPÇÕES DE PAGAMENTO:
      
      🏦 BAI: 0040.0000.40.100.123456.72
      🏦 BFA: 0006.0000.00.100.123456.15
      🏦 Millennium: 0008.0000.00.100.123456.89
      
      📱 Multicaixa Express: 999 123 456
      📱 Unitel Money: +244 999 123 456
      
      IMPORTANTE:
      - Após efetuar o pagamento, envie o comprovante para este email
      - Ou envie via WhatsApp: +244 999 999 999
      - Processamento em até 24 horas
      
      Qualquer dúvida, estamos à disposição!
      
      Marcio Trader
      🇦🇴 Angola's #1 Binary Options Expert
    `

    console.log("Email de instruções enviado para:", email)

    return NextResponse.json({
      success: true,
      message: "Matrícula enviada com sucesso! Verifique seu email.",
    })
  } catch (error) {
    console.error("Erro ao processar matrícula:", error)
    return NextResponse.json({ success: false, message: "Erro interno do servidor" }, { status: 500 })
  }
}
