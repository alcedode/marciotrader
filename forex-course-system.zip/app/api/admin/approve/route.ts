import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { matriculaId, status, telegramLink } = await request.json()

    // Here you would typically:
    // 1. Update the matricula status in database
    // 2. If approved, send email with Telegram link using PHPMailer equivalent
    // 3. Log the action

    if (status === "aprovado") {
      // Simulate sending email with Telegram link
      console.log(`Enviando email de aprovação para matrícula ${matriculaId}`)
      console.log(`Link do Telegram: ${telegramLink}`)

      // Email template would be sent here
      const emailContent = `
        Parabéns! Sua matrícula foi aprovada.
        
        Acesse nosso grupo VIP do Telegram: ${telegramLink}
        
        Bem-vindo ao curso!
      `
    }

    return NextResponse.json({
      success: true,
      message: `Matrícula ${status} com sucesso!`,
    })
  } catch (error) {
    console.error("Erro ao processar aprovação:", error)
    return NextResponse.json({ success: false, message: "Erro interno do servidor" }, { status: 500 })
  }
}
