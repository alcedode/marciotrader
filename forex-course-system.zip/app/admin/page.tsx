"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Check, X, Eye, Mail, Users, Clock, FileText } from "lucide-react"

interface Matricula {
  id: number
  nome: string
  email: string
  telefone: string
  observacoes: string
  comprovante: string
  status: "pendente" | "aprovado" | "rejeitado"
  dataEnvio: string
}

export default function AdminPage() {
  const [matriculas, setMatriculas] = useState<Matricula[]>([
    {
      id: 1,
      nome: "João Silva",
      email: "joao@email.com",
      telefone: "(11) 99999-9999",
      observacoes: "Muito interessado no curso",
      comprovante: "comprovante1.pdf",
      status: "pendente",
      dataEnvio: "2024-01-15",
    },
    {
      id: 2,
      nome: "Maria Santos",
      email: "maria@email.com",
      telefone: "(11) 88888-8888",
      observacoes: "",
      comprovante: "comprovante2.pdf",
      status: "aprovado",
      dataEnvio: "2024-01-14",
    },
    {
      id: 3,
      nome: "Pedro Costa",
      email: "pedro@email.com",
      telefone: "(11) 77777-7777",
      observacoes: "Primeira vez no Forex",
      comprovante: "comprovante3.pdf",
      status: "pendente",
      dataEnvio: "2024-01-16",
    },
  ])

  const [selectedMatricula, setSelectedMatricula] = useState<Matricula | null>(null)
  const [emailTemplate, setEmailTemplate] = useState("")
  const [telegramLink, setTelegramLink] = useState("https://t.me/+exemplo_link_privado")

  const handleStatusChange = (id: number, newStatus: "aprovado" | "rejeitado") => {
    setMatriculas((prev) => prev.map((m) => (m.id === id ? { ...m, status: newStatus } : m)))

    if (newStatus === "aprovado") {
      // Simulate sending email with Telegram link
      console.log(`Enviando email para ${selectedMatricula?.email} com link do Telegram`)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pendente":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
      case "aprovado":
        return "bg-green-500/20 text-green-400 border-green-500/30"
      case "rejeitado":
        return "bg-red-500/20 text-red-400 border-red-500/30"
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/30"
    }
  }

  const pendingCount = matriculas.filter((m) => m.status === "pendente").length
  const approvedCount = matriculas.filter((m) => m.status === "aprovado").length
  const totalCount = matriculas.length

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black p-4">
      <div className="container mx-auto py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-white to-neon-green bg-clip-text text-transparent mb-4">
            Painel Administrativo
          </h1>
          <p className="text-gray-300">Gerencie as matrículas e aprovações do curso</p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gray-900/50 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                  <Clock className="w-6 h-6 text-yellow-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-white">{pendingCount}</p>
                  <p className="text-gray-400 text-sm">Pendentes</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/50 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <Check className="w-6 h-6 text-green-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-white">{approvedCount}</p>
                  <p className="text-gray-400 text-sm">Aprovados</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/50 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-neon-green/20 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-neon-green" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-white">{totalCount}</p>
                  <p className="text-gray-400 text-sm">Total</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/50 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                  <Mail className="w-6 h-6 text-blue-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-white">24</p>
                  <p className="text-gray-400 text-sm">Emails Enviados</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Telegram Link Configuration */}
        <Card className="bg-gray-900/50 border-gray-800 mb-8">
          <CardHeader>
            <CardTitle className="text-white">Configuração do Telegram</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="text-white text-sm font-medium">Link do Grupo Privado</label>
                <Input
                  value={telegramLink}
                  onChange={(e) => setTelegramLink(e.target.value)}
                  className="bg-gray-800 border-gray-700 text-white mt-2"
                  placeholder="https://t.me/+seu_link_privado"
                />
              </div>
              <Button className="bg-neon-green hover:bg-neon-green/90 text-black">Salvar Configuração</Button>
            </div>
          </CardContent>
        </Card>

        {/* Matriculas List */}
        <Card className="bg-gray-900/50 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white">Matrículas Recebidas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {matriculas.map((matricula) => (
                <div
                  key={matricula.id}
                  className="border border-gray-700 rounded-lg p-4 hover:border-neon-green/30 transition-colors"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-white font-semibold">{matricula.nome}</h3>
                      <p className="text-gray-400 text-sm">{matricula.email}</p>
                    </div>
                    <Badge className={getStatusColor(matricula.status)}>{matricula.status.toUpperCase()}</Badge>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-gray-400 text-sm">
                        Telefone: <span className="text-white">{matricula.telefone}</span>
                      </p>
                      <p className="text-gray-400 text-sm">
                        Data: <span className="text-white">{matricula.dataEnvio}</span>
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-sm">
                        Comprovante: <span className="text-white">{matricula.comprovante}</span>
                      </p>
                    </div>
                  </div>

                  {matricula.observacoes && (
                    <div className="mb-4">
                      <p className="text-gray-400 text-sm">Observações:</p>
                      <p className="text-white text-sm">{matricula.observacoes}</p>
                    </div>
                  )}

                  <div className="flex gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-gray-600 text-gray-300 hover:bg-gray-800 bg-transparent"
                          onClick={() => setSelectedMatricula(matricula)}
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          Ver Comprovante
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="bg-gray-900 border-gray-700">
                        <DialogHeader>
                          <DialogTitle className="text-white">Comprovante de Pagamento</DialogTitle>
                        </DialogHeader>
                        <div className="p-4">
                          <div className="bg-gray-800 rounded-lg p-8 text-center">
                            <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                            <p className="text-gray-300">Visualização do arquivo:</p>
                            <p className="text-white font-semibold">{matricula.comprovante}</p>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>

                    {matricula.status === "pendente" && (
                      <>
                        <Button
                          size="sm"
                          className="bg-green-600 hover:bg-green-700 text-white"
                          onClick={() => handleStatusChange(matricula.id, "aprovado")}
                        >
                          <Check className="w-4 h-4 mr-2" />
                          Aprovar
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleStatusChange(matricula.id, "rejeitado")}
                        >
                          <X className="w-4 h-4 mr-2" />
                          Rejeitar
                        </Button>
                      </>
                    )}

                    {matricula.status === "aprovado" && (
                      <Button size="sm" className="bg-neon-green hover:bg-neon-green/90 text-black">
                        <Mail className="w-4 h-4 mr-2" />
                        Reenviar Link
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
